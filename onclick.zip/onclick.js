

function submeterReply() {
    document.getElementById("subMensagem").innerHTML = "<h3>Obrigado por participar!<h3>";
   
}